﻿namespace LRS.Interfaces
{
    public interface IOrganization
    {
        string OrgId { get; }
        string Description { get; }
    }
}
