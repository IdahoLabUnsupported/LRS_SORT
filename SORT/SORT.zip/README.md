## Synopsis

This is the MVC Template project, which we (INL IM Y310 .NET Team) use to start new MVC projects.

This is Don King's Branch!