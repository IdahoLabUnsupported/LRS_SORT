﻿namespace Sort.Interfaces
{
    public interface IOrganization
    {
        string OrgId { get; }
        string Description { get; }
        string DisplayName { get; }
    }
}
